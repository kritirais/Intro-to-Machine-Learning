#!/usr/bin/python

""" 
    This is the code to accompany the Lesson 2 (SVM) mini-project.

    Use a SVM to identify emails from the Enron corpus by their authors:    
    Sara has label 0
    Chris has label 1
"""
    
import sys
import time
from sklearn import svm
from sklearn.metrics import accuracy_score
import collections
sys.path.append("../tools/")
from email_preprocess import preprocess


### features_train and features_test are the features for the training
### and testing datasets, respectively
### labels_train and labels_test are the corresponding item labels
st_time = time.time()
features_train, features_test, labels_train, labels_test = preprocess()
end_time = time.time()
time_ = (end_time - st_time) / 60
print('Data classification time:', time_, 'mins.')




#########################################################
### your code goes here ###

#########################################################
# Creating the classifier using linear kernel
# clf_svm = svm.SVC(kernel = 'linear')
# Creating the classifier using rbf kernel and varying C
# C = 10.0
# C = 100.0
# C = 1000.0
C = 10000.0
clf_svm = svm.SVC(kernel = 'rbf', C = C)


#Training the classifier on the complete dataset
st_time = time.time()
clf_svm.fit(features_train, labels_train)
end_time = time.time()
time_ = (end_time - st_time) / 60
print('Classifier training time:', time_, 'mins.')

#Training the classifier on smaller subset of training data
# features_train = features_train[: len(features_train) // 100]
# labels_train = labels_train[: len(labels_train) // 100]
# st_time = time.time()
# clf_svm.fit(features_train, labels_train)
# end_time = time.time()
# time_ = (end_time - st_time) / 60
# print('Classifier training time:', time_, 'mins.')


#Testing the classifier
st_time = time.time()
pred_labels = clf_svm.predict(features_test)
end_time = time.time()
time_ = (end_time - st_time) / 60
print('Classifier testing time:', time_, 'mins.')

#Counting number of Chris events predicted
print('Chris mails predicted:', collections.Counter(pred_labels)[1])


#Accuracy of the classifier
st_time = time.time()
acc_clf = (accuracy_score(labels_test, pred_labels) * 100)
end_time = time.time()
time_ = (end_time - st_time) / 60
print('The accuracy of the classifier with C =', C, 'is', acc_clf, '%')
print('Accuracy calculation time:', time_, 'mins.')








