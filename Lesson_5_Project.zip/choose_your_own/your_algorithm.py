#!/usr/bin/python

import matplotlib.pyplot as plt
from sklearn.ensemble import AdaBoostClassifier, RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier 
from prep_terrain_data import makeTerrainData
from class_vis import prettyPicture
from time import time

features_train, labels_train, features_test, labels_test = makeTerrainData()


### the training data (features_train, labels_train) have both "fast" and "slow"
### points mixed together--separate them so we can give them different colors
### in the scatterplot and identify them visually
grade_fast = [features_train[ii][0] for ii in range(0, len(features_train)) if labels_train[ii]==0]
bumpy_fast = [features_train[ii][1] for ii in range(0, len(features_train)) if labels_train[ii]==0]
grade_slow = [features_train[ii][0] for ii in range(0, len(features_train)) if labels_train[ii]==1]
bumpy_slow = [features_train[ii][1] for ii in range(0, len(features_train)) if labels_train[ii]==1]


#### initial visualization
plt.xlim(0.0, 1.0)
plt.ylim(0.0, 1.0)
plt.scatter(bumpy_fast, grade_fast, color = "b", label="fast")
plt.scatter(grade_slow, bumpy_slow, color = "r", label="slow")
plt.legend()
plt.xlabel("bumpiness")
plt.ylabel("grade")
plt.show()
################################################################################


### your code here!  name your classifier object clf if you want the 
### visualization code (prettyPicture) to show you the decision boundary

### Ada-Boost Classifier
print('Using Ada-Boost Classifier')
print()
clf_ada = AdaBoostClassifier()

fit_st = time()
clf_ada.fit(features_train, labels_train)
fit_end = time()
diff_time = round((fit_end - fit_st) / 60, 4)
print('Training time:', diff_time, 'mins.')

pred_st = time()
pred_labels = clf_ada.predict(features_test)
pred_end = time()
diff_time = round((pred_end - pred_st) / 60, 4)
print('Testing time:', diff_time, 'mins.')

acc = clf_ada.score(features_test, labels_test) * 100
print('Accuracy:', acc, '%')
print()

### K-NN Classifier
print('Using K-NN Classifier')
print()
clf_knn = KNeighborsClassifier()

fit_st = time()
clf_knn.fit(features_train, labels_train)
fit_end = time()
diff_time = round((fit_end - fit_st) / 60, 4)
print('Training time:', diff_time, 'mins.')

pred_st = time()
pred_labels = clf_knn.predict(features_test)
pred_end = time()
diff_time = round((pred_end - pred_st) / 60, 4)
print('Testing time:', diff_time, 'mins.')

acc = clf_knn.score(features_test, labels_test) * 100
print('Accuracy:', acc, '%')
print()

### Random Forest Classifier
print('Using Random Forest Classifier')
print()
clf_rf = RandomForestClassifier()

fit_st = time()
clf_rf.fit(features_train, labels_train)
fit_end = time()
diff_time = round((fit_end - fit_st) / 60, 4)
print('Training time:', diff_time, 'mins.')

pred_st = time()
pred_labels = clf_rf.predict(features_test)
pred_end = time()
diff_time = round((pred_end - pred_st) / 60, 4)
print('Testing time:', diff_time, 'mins.')

acc = clf_rf.score(features_test, labels_test) * 100
print('Accuracy:', acc, '%')
print()


try:
    prettyPicture(clf_ada, features_test, labels_test)
    # prettyPicture(clf_knn, features_test, labels_test)
    # prettyPicture(clf_rf, features_test, labels_test)
except NameError:
    pass
