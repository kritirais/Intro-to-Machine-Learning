#!/usr/bin/python

""" 
    This is the code to accompany the Lesson 3 (decision tree) mini-project.

    Use a Decision Tree to identify emails from the Enron corpus by author:    
    Sara has label 0
    Chris has label 1
"""
    
import sys
from time import time
from sklearn import tree
sys.path.append("../tools/")
from email_preprocess import preprocess


### features_train and features_test are the features for the training
### and testing datasets, respectively
### labels_train and labels_test are the corresponding item labels
features_train, features_test, labels_train, labels_test = preprocess()




#########################################################
### your code goes here ###
clf = tree.DecisionTreeClassifier(min_samples_split = 40)

fit_st = time()
clf.fit(features_train, labels_train)
fit_end = time()
diff_time = round((fit_end - fit_st) / 60, 2)
print('Training time:', diff_time, 'min.')

pred_st = time()
pred_labels = clf.predict(features_test)
pred_end = time()
diff_time = round((pred_end - pred_st) / 60, 4)
print('Testing time:', diff_time, 'min.')

acc_score = clf.score(features_test, labels_test) * 100
print('The accuracy of the classifier is', acc_score, '%')



#########################################################


